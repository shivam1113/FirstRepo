

create table shoppingmart (productID number(3) primary key,productname varchar2(20) not null,priceperunit number(4,2) not null,noOfunits number(3) not null,instock check in('AVAILABLE','NOTAVAILABLE');

insert into shoppingmart values (1,'suffola gold',450,50,'available');
insert into shoppingmart values  (2,'ashirvaad atta',40,49,'available');
insert into shoppingmart values (3,'chikki panvel',99,8,'available');
insert into shoppingmart values(4,'tata salt',18,99,'available');



create table customershistory (customerid number(3),customername varchar2(30),customerno number(10),productid foreign key references shoppingmart(productid),dateofdel date);

