package com.cg.shopmart.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.shopmart.bean.CustomerBean;
import com.cg.shopmart.bean.ShopBean;
import com.cg.shopmart.exception.ShopException;
import com.cg.shopmart.service.IShopService;
import com.cg.shopmart.service.ShopService;

@WebServlet("*.do")
public class ShopController extends HttpServlet {
	private static final long serialVersionUID = 1L;
   IShopService service;
    public ShopController() {
        super();
        // TODO Auto-generated constructor stub
        service=new ShopService();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
		}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path=request.getServletPath().trim();
		HttpSession session=request.getSession(true);
		@SuppressWarnings("unused")
		ShopBean bean=null;
		switch(path)
		{
		case "/productList.do":
		{
			try{
				List<ShopBean> productList=service.getAllProducts();
				if(productList.size()>0)
				{
				session.setAttribute("productList", productList);
				request.getRequestDispatcher("home.jsp").forward(request, response);
				}
				else
				{	
					
					request.getRequestDispatcher("error.jsp").forward(request, response);

				}
				break;
				
				}
			catch(ShopException | SQLException e){
				e.printStackTrace();
			}
		break;
		}
		case "/custDetails.do":
		{
			int productID=Integer.parseInt(request.getParameter("pid"));
			System.out.println(productID);
			List<ShopBean> productList;
			try {
			productList = service.getProducts(productID);
			
			if(productList.size()>0)
			{
			session.setAttribute("productList", productList);
			request.getRequestDispatcher("home1.jsp").forward(request, response);
			}
			else
			{	
				
				request.getRequestDispatcher("error.jsp").forward(request, response);

			}
			} catch (ShopException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		break;
		}
		case "/newEntry.do":
		{
			
			int productID= (int) session.getAttribute("productID");
			String customerName =request.getParameter("name");
			Long customerNo=Long.parseLong(request.getParameter("number"));
			int units=Integer.parseInt(request.getParameter("units"));
			int quantity=(int) session.getAttribute("quantity");
			LocalDate date=LocalDate.parse(request.getParameter("date"));	// getting date from HTML form 
							System.out.println(productID+" "+customerName+" "+customerNo+" "+units+" "+quantity+" "+date);
			if(units<=quantity)
			{
				CustomerBean custBean=new CustomerBean(productID,customerName, customerNo,date);
				try {
					int success=service.addNewCustomer(custBean);
					if(success<=0)
					{
						session.setAttribute("units", units);
						request.getRequestDispatcher("errorQuantity.jsp").forward(request,response);
					}
					else
					{
						service.updateProduct(productID);
						session.setAttribute("success", success);
						session.setAttribute("date", date);	
						request.getRequestDispatcher("successEntry.jsp").forward(request,response);
					}
				} catch (ShopException e) {
					e.printStackTrace();
				} catch (SQLException e) {
					e.printStackTrace();
				}
				
			}
			else
			{
				session.setAttribute("units", units);
				request.getRequestDispatcher("errorQuantity.jsp").forward(request,response);
			}
						break;
		}
		case "/customerDetails.do":
		{
			
			int productID=Integer.parseInt(request.getParameter("productID"));
			int price=Integer.parseInt(request.getParameter("price"));
			int quantity=Integer.parseInt(request.getParameter("quantity"));
			String productName=request.getParameter("productName");
			System.out.println(productID+" "+quantity+" "+price+" "+productName);
			session.setAttribute("productName",productName);
			session.setAttribute("productID",productID);
			session.setAttribute("quantity",quantity);
			session.setAttribute("price",price);
			request.getRequestDispatcher("newEntry.jsp").forward(request, response);
			
			break;
		}
		case "/viewCustDetails.do":
		{
			try{
				String custName=request.getParameter("cust");
				System.out.println(custName);
				List<CustomerBean> custList=service.getAllPurchases(custName);
				if(custList.size()>0)
				{
				CustomerBean cust=custList.get(0);
				session.setAttribute("custName", custName);
				session.setAttribute("custList", custList);
				request.getRequestDispatcher("PurchaseHistory.jsp").forward(request, response);
				}
				else
				{	session.setAttribute("custName", custName);
					request.getRequestDispatcher("error.jsp").forward(request, response);

				}
				break;
				
				}
			catch(ShopException | SQLException e){
				e.printStackTrace();
			}
		break;
		}
		
		}
		
}

}
