package com.cg.shopmart.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.shopmart.bean.CustomerBean;
import com.cg.shopmart.bean.ShopBean;
import com.cg.shopmart.exception.ShopException;

public interface IShopDao {
	public List<ShopBean> getAllProducts() throws ShopException, SQLException;
	public int addNewCustomer(CustomerBean bean) throws ShopException, SQLException;
	public int updateProduct(int id) throws ShopException, SQLException;
	public List<CustomerBean> getAllPurchases(String custName) throws ShopException, SQLException;
	public List<ShopBean> getProducts(int productID) throws ShopException, SQLException;
}
