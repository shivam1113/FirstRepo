package com.cg.shopmart.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.shopmart.bean.CustomerBean;
import com.cg.shopmart.bean.ShopBean;
import com.cg.shopmart.exception.ShopException;
import com.cg.shopmart.util.DBConnectionUtil;

public class ShopDao implements IShopDao {

	@Override
	public List<ShopBean> getAllProducts() throws ShopException, SQLException {
		List<ShopBean> productList=new ArrayList<ShopBean>();
		ShopBean shopBean;
		String query="SELECT * FROM shoppingmart";
		try(
			Connection conn=DBConnectionUtil.getConnection();
			Statement statement=conn.createStatement();
			ResultSet rs=statement.executeQuery(query);
		)
		{
			while(rs.next())
			{
				
				int productID=rs.getInt("PRODUCTID");
				String productName=rs.getString("PRODUCTNAME");
				int price=rs.getInt("PRICEPERUNIT");
				int units=rs.getInt("NOOFUNITS");
				shopBean=new ShopBean(productID, productName, price, units);
				productList.add(shopBean);
				
			}
		}
			catch(SQLException e)
			{
				throw new ShopException("sql :"+e.getMessage());
			}
			catch(Exception e){
				throw new ShopException("ERROR :"+e.getMessage());
		}
		return productList;
	}

	@Override
	public int addNewCustomer(CustomerBean bean) throws ShopException, SQLException {
		String qry="INSERT INTO customershistory values (?,?,?,?,?)";
		try(
				Connection conn=DBConnectionUtil.getConnection();
				PreparedStatement statement=conn.prepareStatement(qry);)
			{
				Date date=Date.valueOf(bean.getDate());	//date.sql.date Date.valueOf(bean.getDate()); converts
														//local date to sql date
				bean.setCustomerID(getCustID());
				statement.setInt(1, bean.getCustomerID());
				statement.setString(2, bean.getCustomerName());
				statement.setLong(3, bean.getCustomerNo());
				statement.setInt(4, bean.getProductID());
				statement.setDate(5,date);				//setting sql date and take as localdate in bean
				statement.executeQuery();	// for successfull insert
			}
		catch(SQLException e)
		{
			throw new ShopException("SQL ERROR: "+e.getMessage());
		}
		catch(Exception e)
		{
			throw new ShopException("ERROR: "+e.getMessage());
		}
		return bean.getCustomerID();
	}
	private int getCustID() throws ShopException{
		int custID=0;
		String query="SELECT cust_id_seq.NEXTVAL FROM DUAL";
		try(Connection conn=DBConnectionUtil.getConnection();
				Statement statement=conn.createStatement();
				ResultSet rs=statement.executeQuery(query);
			)
			{
			if(rs.next())
			{
				custID=rs.getInt(1);
			}
			}
		catch(SQLException e)
		{
			throw new ShopException("Unable to generate Transaction ID.");
		}
		
		return custID;
		
	}

		@Override
		public int updateProduct(int id) throws ShopException, SQLException {
			String qry="UPDATE shoppingmart SET noofUnits=(noofUnits-1) where PRODUCTID="+id;
			Connection conn=DBConnectionUtil.getConnection();
			PreparedStatement statement=conn.prepareStatement(qry);
			statement.execute();
			return 1;
		}

		@Override
		public List<CustomerBean> getAllPurchases(String custName) throws ShopException,
			SQLException {
			List<CustomerBean> purchaseList=new ArrayList<CustomerBean>();
			CustomerBean custBean;
			int customerID=0,productId=0,noofunits=0;
			String customerName=null;
					long customerNo=0;
			String query="SELECT * FROM ShoppingMart where productID IN(Select productID from customershistory where customername='"+custName+"')";
			String query1="Select customerid from customershistory where customername='"+custName+"'";
			try(
				Connection conn=DBConnectionUtil.getConnection();
				Statement statement=conn.createStatement();
				ResultSet rs=statement.executeQuery(query);
			)
			{
				while(rs.next())
				{
					productId=rs.getInt("PRODUCTID");
					customerName=rs.getString("PRODUCTNAME");
					customerNo=rs.getLong("PRICEPERUNIT");
					noofunits=rs.getInt("NOOFUNITS");
				}
				ResultSet rs1=statement.executeQuery(query1);
				while(rs1.next())
				{
						customerID=rs1.getInt("CustomerID");	
				}
				System.out.println(productId+" "+customerName+" "+customerNo+" "+customerID);
					custBean=new CustomerBean(customerID, customerName,customerNo,productId );
					purchaseList.add(custBean);
			}
				catch(SQLException e)
				{
					throw new ShopException("sql :"+e.getMessage());
				}
				catch(Exception e){
					throw new ShopException("ERROR :"+e.getMessage());
			}
			return purchaseList;
		}

		@Override
		public List<ShopBean> getProducts(int productID) throws ShopException,
				SQLException {
			List<ShopBean> productLists=new ArrayList<ShopBean>();
			ShopBean shopBean;
			String query="SELECT * FROM shoppingmart where productid="+productID;
			try(
				Connection conn=DBConnectionUtil.getConnection();
				Statement statement=conn.createStatement();
				ResultSet rs=statement.executeQuery(query);
			)
			{
				while(rs.next())
				{
					
					int pID=rs.getInt("PRODUCTID");
					String productName=rs.getString("PRODUCTNAME");
					int price=rs.getInt("PRICEPERUNIT");
					int units=rs.getInt("NOOFUNITS");
					shopBean=new ShopBean(pID, productName, price, units);
					productLists.add(shopBean);
					
				}
			}
				catch(SQLException e)
				{
					throw new ShopException("sql :"+e.getMessage());
				}
				catch(Exception e){
					throw new ShopException("ERROR :"+e.getMessage());
			}
			return productLists;

		}

		}