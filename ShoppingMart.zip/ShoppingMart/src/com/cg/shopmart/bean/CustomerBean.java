package com.cg.shopmart.bean;

import java.time.LocalDate;

public class CustomerBean {
	private int customerID;
	private String customerName;
	private Long customerNo;
	private int productID;
	private LocalDate date;
		public CustomerBean(int productID,String customerName, Long customerNo
			,LocalDate date) {
		super();
		this.date=date;
		this.customerName = customerName;
		this.customerNo = customerNo;
		this.productID = productID;
	}
	public LocalDate getDate() {
			return date;
		}
		public void setDate(LocalDate date) {
			this.date = date;
		}
	@Override
	public String toString() {
		return "CustomerBean [customerID=" + customerID + ", customerName="
				+ customerName + ", customerNo=" + customerNo + ", productID="
				+ productID + "]";
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public Long getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(Long customerNo) {
		this.customerNo = customerNo;
	}
	public int getProductID() {
		return productID;
	}
	public void setProductID(int productID) {
		this.productID = productID;
	}
	public CustomerBean(int customerID, String customerName, Long customerNo,
			int productID) {
		super();
		this.customerID = customerID;
		this.customerName = customerName;
		this.customerNo = customerNo;
		this.productID = productID;
	}





}

